﻿$(function () {
    console.log("hello");
    var id = $("#txtDeliveryDate");
    console.log(id);
    id.datepicker();

});