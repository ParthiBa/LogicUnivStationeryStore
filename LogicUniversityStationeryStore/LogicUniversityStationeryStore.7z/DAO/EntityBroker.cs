﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LogicUniversityStationeryStore.DAO
{
    public class EntityBroker 
    {


        private static LogicUnivesrityEntities ctx = new LogicUnivesrityEntities();
        public static LogicUnivesrityEntities getMyEntites()
        {
            return ctx;
        }
    }
}