﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LogicUniversityStationeryStore.Controller
{
    public class DisbursementController
    {

        //LogicUniversityEntities context = new LogicUniversityEntities();
        //// LogicStationeryEntities context = new LogicStationeryEntities(); 

    
        ////for binding into Representative Name and Collection Point according to Department 
        //public Department getDepartmentData(string deptName)
        //{
        //    var q = from dp in context.Departments
                            
        //            where dp.name == deptName
        //            select dp;
        //    Department m = q.First<Department>();
        //    return m;
        //}

        ////for binding Delivery Date according to Department
        //public DateTime getDeliveryDate(String deptName)
        //{
        //    var date = from d in context.DisbursementLists
        //               join dp in context.Departments on d.deptCode equals dp.code
        //               where dp.code == deptName
        //               select d.deliveryDate;
        //    DateTime dt = date.First<DateTime>();
        //    return dt;
        //}
    
     

      }
}